function flipCard(element) {
    element.querySelector('.flip-card').classList.toggle('flipped');
}